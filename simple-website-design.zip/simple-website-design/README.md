# Simple Website Design

A Pen created on CodePen.io. Original URL: [https://codepen.io/Andrew-Cromar/pen/poQPGYE](https://codepen.io/Andrew-Cromar/pen/poQPGYE).

